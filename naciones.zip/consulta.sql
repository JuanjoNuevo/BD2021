select c.name from languages l, country_languages x, countries c where language='Spanish' and l.language_id=x.language_id and c.country_id=x.country_id;

